﻿using System;
using System.Linq;
using System.Reflection.Metadata;
using HidSharp;

namespace Device.SpiDriver
{
    /*****************************************************************************
        Code Mercenaries Hard- und Software/
            IO-Warrior56-DG : SPI-USBコンバータ用制御コマンド
    *****************************************************************************/
    public class IoWarrior56Spi : ISpiDriver
    {
        private HidDevice? device = null!;
        private HidStream stream = null!;

        // SPI 設定保持
        private uint speed = 1000000; // 1MHz
        private int mode = 0;

        // ---------------------------------------------------------
        // 初期化
        // ---------------------------------------------------------
        public void Open()
        {
            var list = DeviceList.Local;
            device = list.GetHidDevices(0x07C0, 0x1501).FirstOrDefault(); // IO-Warrior56-DG

            if (device == null)
                throw new Exception("IO-Warrior56-DG が見つかりません");

            stream = device.Open();
            stream.ReadTimeout = Timeout.Infinite;
            stream.WriteTimeout = Timeout.Infinite;

            ApplySpiConfig();
        }

        public void Close()
        {

        }

        // ---------------------------------------------------------
        // HID レポート送受信
        // ---------------------------------------------------------
        private void WriteReport(byte[] report)
        {
            stream.Write(report);
        }

        private byte[] ReadReport()
        {
            byte[] buf = new byte[64];
            stream.Read(buf, 0, buf.Length);
            return buf;
        }

        // ---------------------------------------------------------
        // SPI 設定（0x01）
        // ---------------------------------------------------------
        private void ApplySpiConfig()
        {
            byte[] report = new byte[64];
            report[1] = 0x01; // SPI Config

            report[2] = (byte)(speed & 0xFF);
            report[3] = (byte)((speed >> 8) & 0xFF);

            report[4] = (byte)mode; // SPI Mode 0〜3

            WriteReport(report);
            ReadReport();
        }

        public void SetSpeed(uint hz)
        {
            speed = hz;
            ApplySpiConfig();
        }

        public void SetMode(int m)
        {
            mode = m;
            ApplySpiConfig();
        }

        // CS Manual Control
        public void SetCsPin(int pin)
        { }
        public void CsLow() => GpioWrite(0, false);
        public void CsHigh() => GpioWrite(0, true);

        // ---------------------------------------------------------
        // SPI 転送（0x02）
        // ---------------------------------------------------------
        public byte[] Transfer(byte[] tx)
        {
            byte[] report = new byte[64];
            report[1] = 0x02; // SPI Transfer

            report[2] = (byte)tx.Length;
            Array.Copy(tx, 0, report, 3, tx.Length);

            WriteReport(report);
            var res = ReadReport();

            byte[] rx = new byte[tx.Length];
            Array.Copy(res, 3, rx, 0, tx.Length);

            return rx;
        }

        public void Write(byte[] data)
        {
            Transfer(data);
        }

        public byte[] ReadBytes(int count)
        {
            byte[] tx = new byte[count];
            return Transfer(tx);
        }

        public ushort Read16()
        {
            var rx = ReadBytes(2);
            return (ushort)((rx[0] << 8) | rx[1]);
        }

        public uint Read24()
        {
            var rx = ReadBytes(3);
            return (uint)((rx[0] << 16) | (rx[1] << 8) | rx[2]);
        }

        public uint Read32()
        {
            var rx = ReadBytes(4);
            return (uint)((rx[0] << 24) | (rx[1] << 16) | (rx[2] << 8) | rx[3]);
        }

        // ---------------------------------------------------------
        // GPIO 制御（0x03 / 0x04）
        // ---------------------------------------------------------
        public void GpioSetDirection(int pin, bool isOutput)
        {
            byte[] report = new byte[64];
            report[1] = 0x03; // GPIO Config

            report[2] = (byte)pin;
            report[3] = (byte)(isOutput ? 1 : 0);

            WriteReport(report);
            ReadReport();
        }

        public void GpioWrite(int pin, bool level)
        {
            byte[] report = new byte[64];
            report[1] = 0x04; // GPIO Write

            report[2] = (byte)pin;
            report[3] = (byte)(level ? 1 : 0);

            WriteReport(report);
            ReadReport();
        }

        public bool GpioRead(int pin)
        {
            byte[] report = new byte[64];
            report[1] = 0x05; // GPIO Read

            report[2] = (byte)pin;

            WriteReport(report);
            var res = ReadReport();

            return res[3] != 0;
        }

        public void GpioSetDirectionMask(uint mask)
        {
            for (int i = 0; i < 32; i++)
                GpioSetDirection(i, ((mask >> i) & 1) == 1);
        }

        public void GpioWriteMask(uint mask)
        {
            for (int i = 0; i < 32; i++)
                GpioWrite(i, ((mask >> i) & 1) == 1);
        }

        public uint GpioReadMask()
        {
            uint val = 0;
            for (int i = 0; i < 32; i++)
                if (GpioRead(i))
                    val |= (uint)(1 << i);
            return val;
        }
    }
}
