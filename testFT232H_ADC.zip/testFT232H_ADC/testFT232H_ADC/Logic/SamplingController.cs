﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Device.Adc;

namespace testFT232H_ADC.Logic
{
    /*****************************************************************************
        平均処理
    *****************************************************************************/
    internal class SamplingController
    {
        private readonly Ad7276 adc;

        public SamplingController(Ad7276 adc)
        {
            this.adc = adc;
        }

        public int SampleAverage(int count)
        {
            long sum = 0;

            for (int i = 0; i < count; i++)
            {
                sum += adc.ReadSample();
            }

            return (int)(sum / count);
        }
    }
}
