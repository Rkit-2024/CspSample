﻿using System.Text;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;

using Device.SpiDriver;
using Device.Adc;
using testFT232H_ADC.Logic;

namespace testFT232H_ADC
{
    /*****************************************************************************
        SPI-USBコンバータICを使ったA/DコンバータICデータサンプリングサンプル 
    
        ADC：AD7276
        Tms間隔でサンプリングデータをグラフ表示
        Tms内でn個データをサンプリングして平均
    *****************************************************************************/
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ISpiDriver spi = null!;

        private Ad7276 adc = null!;
        private SamplingController sampler;
        private GraphRenderer graph;

        private DispatcherTimer timer;
        private List<int> samples = new List<int>();

        private int averageCount = 8;      // N: 平均回数
        private int intervalMs = 500;      // T: 表示周期 [ms]

        public MainWindow()
        {
            InitializeComponent();

            // FT232H
            spi = new FtdiSpi();
            // MCP2210
            // spi = new McpSpi();

            spi.Open();

            var adc = new Ad7276(spi);
            sampler = new SamplingController(adc);
            graph = new GraphRenderer();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(intervalMs);
            timer.Tick += Timer_Tick;                                   // TickイベントにTimer_Tickメソッドを登録, +=はイベント登録演算子
        }

        private bool UpdateSettingsFromUi()
        {
            StatusText.Text = "";

            if (!int.TryParse(AverageCountText.Text, out int n))
            {
                StatusText.Text = "平均回数が不正です";
                return false;
            }
            if (n < 1 || n > 32)
            {
                StatusText.Text = "平均回数は1～32の範囲で指定してください";
                return false;
            }

            if (!int.TryParse(IntervalText.Text, out int t))
            {
                StatusText.Text = "表示周期が不正です";
                return false;
            }
            if (t < 100 || t > 1000)
            {
                StatusText.Text = "表示周期は100～1000msの範囲で指定してください";
                return false;
            }

            averageCount = n;
            intervalMs = t;
            timer.Interval = TimeSpan.FromMilliseconds(intervalMs);

            return true;
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (!UpdateSettingsFromUi())
                return;

            samples.Clear();
            OutputText.Clear();
            timer.Start();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
        }

        private void Timer_Tick(object? sender, EventArgs? e)
        {
            int avg = sampler.SampleAverage(averageCount);

            samples.Add(avg);

            OutputText.AppendText($"{DateTime.Now:HH:mm:ss.fff} : Avg({averageCount}) = {avg}\n");
            OutputText.ScrollToEnd();

            graph.Draw(GraphCanvas, samples);
        }
    }
}