﻿using System;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using Device.Dac;
using Device.SpiDriver;

namespace testFT232H_ADC
{
    public partial class WindowDAC : Window
    {
        private ISpiDriver spi;
        private Ad5624r dac;

        private ushort[] currentWave = Array.Empty<ushort>();
        private CancellationTokenSource? cts;

        public WindowDAC()
        {
            InitializeComponent();

            // 実機に合わせてここを差し替え
            spi = new FtdiSpi();

            spi.Open();
            spi.SetCsPin(4);

            dac = new Ad5624r(spi);
        }

        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int points = int.Parse(PointsBox.Text);
                int amp = int.Parse(AmplitudeBox.Text);
                int offset = int.Parse(OffsetBox.Text);

                string waveType = ((ComboBoxItem)WaveTypeCombo.SelectedItem!).Content.ToString()!;

                currentWave = GenerateWave(waveType, points, amp, offset);
                StatusText.Text = $"Wave generated: {waveType}, {points} pts.";
            }
            catch (Exception ex)
            {
                StatusText.Text = $"Error: {ex.Message}";
            }
        }

        private ushort[] GenerateWave(string type, int points, int amplitude, int offset)
        {
            var data = new ushort[points];

            switch (type)
            {
                case "Sine":
                    for (int i = 0; i < points; i++)
                    {
                        double t = (double)i / points;
                        double v = offset + amplitude * Math.Sin(2 * Math.PI * t);
                        data[i] = Clamp12(v);
                    }
                    break;

                case "Square":
                    for (int i = 0; i < points; i++)
                    {
                        double t = (double)i / points;
                        double v = t < 0.5 ? offset + amplitude : offset - amplitude;
                        data[i] = Clamp12(v);
                    }
                    break;

                case "Triangle":
                    for (int i = 0; i < points; i++)
                    {
                        double t = (double)i / points;
                        double v = t < 0.5
                            ? offset + amplitude * (4 * t - 1)
                            : offset + amplitude * (3 - 4 * t);
                        data[i] = Clamp12(v);
                    }
                    break;

                case "DC":
                    for (int i = 0; i < points; i++)
                        data[i] = Clamp12(offset);
                    break;
            }

            return data;
        }

        private static ushort Clamp12(double v)
        {
            if (v < 0) v = 0;
            if (v > 4095) v = 4095;
            return (ushort)v;
        }

        private Ad5624r.Channel GetSelectedChannel()
        {
            string ch = ((ComboBoxItem)ChannelCombo.SelectedItem!).Content.ToString()!;
            return ch switch
            {
                "A" => Ad5624r.Channel.A,
                "B" => Ad5624r.Channel.B,
                "C" => Ad5624r.Channel.C,
                "D" => Ad5624r.Channel.D,
                _ => Ad5624r.Channel.A
            };
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentWave.Length == 0)
            {
                StatusText.Text = "Generate wave first.";
                return;
            }

            if (cts != null)
            {
                StatusText.Text = "Already running.";
                return;
            }

            try
            {
                int intervalUs = int.Parse(IntervalBox.Text);
                var ch = GetSelectedChannel();

                cts = new CancellationTokenSource();
                var token = cts.Token;

                StatusText.Text = "Running...";

                Task.Run(() =>
                {
                    try
                    {
                        while (!token.IsCancellationRequested)
                        {
                            dac.WriteWaveform(ch, currentWave, intervalUs);
                        }
                    }
                    catch (OperationCanceledException) { }
                    catch (Exception ex)
                    {
                        Dispatcher.Invoke(() => StatusText.Text = $"Error: {ex.Message}");
                    }
                    finally
                    {
                        Dispatcher.Invoke(() =>
                        {
                            StatusText.Text = "Stopped.";
                            cts = null;
                        });
                    }
                }, token);
            }
            catch (Exception ex)
            {
                StatusText.Text = $"Error: {ex.Message}";
            }
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            cts?.Cancel();
        }

        protected override void OnClosed(EventArgs e)
        {
            cts?.Cancel();
            spi?.Close();
            base.OnClosed(e);
        }

        private void LoadCsvButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*"
            };

            if (dialog.ShowDialog() != true)
                return;

            try
            {
                var lines = System.IO.File.ReadAllLines(dialog.FileName);

                // 空行や空白を除去
                var values = lines
                    .Select(l => l.Trim())
                    .Where(l => !string.IsNullOrWhiteSpace(l))
                    .Select(l => double.Parse(l))
                    .ToArray();

                // ushort に変換（0〜4095）
                currentWave = values
                    .Select(v =>
                    {
                        if (v < 0) v = 0;
                        if (v > 4095) v = 4095;
                        return (ushort)v;
                    })
                    .ToArray();

                StatusText.Text = $"Loaded CSV: {currentWave.Length} pts";
            }
            catch (Exception ex)
            {
                StatusText.Text = $"CSV Load Error: {ex.Message}";
            }
        }
    }
}