HIDSharp is a cross-platform .NET wrapper for Windows, MacOS, and Linux (hidraw) USB HID APIs.
      
It can interface with arbitrary USB HID devices as well as read and write raw reports.

It also includes cross-platform serial port communications and supports interprocess communication for exclusion of HID devices between programs.