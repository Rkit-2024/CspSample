﻿using Device.SpiDriver;

namespace Device.Adc
{
    /*****************************************************************************
        ADI/AD7276 : A/DコンバータIC用制御コマンド
    *****************************************************************************/
    public class Ad7276
    {
        private readonly ISpiDriver spi;

        public Ad7276(ISpiDriver spi)
        {
            this.spi = spi;
        }

        public int ReadSample()
        {
            ushort raw = spi.Read16();
            int value = raw >> 4 & 0x0FFF; // 上位12bit
            return value;
        }
    }
}