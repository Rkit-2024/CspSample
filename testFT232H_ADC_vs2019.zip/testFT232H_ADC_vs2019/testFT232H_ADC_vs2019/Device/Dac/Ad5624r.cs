﻿using System;
using System.Linq;

using Device.SpiDriver;

namespace Device.Dac
{
    /*****************************************************************************
        ADI/AD5624R : D/AコンバータIC用制御コマンド
        *FT232H系限定
            任意波形連続出力はFT232H系でないと対応できない
    *****************************************************************************/
    public class Ad5624r
    {
        private readonly ISpiDriver spi;

        public enum Channel
        {
            A = 0,
            B = 1,
            C = 2,
            D = 3
        }

        public Ad5624r(ISpiDriver spi)
        {
            this.spi = spi;
            spi.SetMode(1);     // AD5624R は Mode1 が一般的
            spi.SetSpeed(10000000); // 10MHz
        }

        // 24bit フレーム生成
        private static byte[] BuildFrame(Channel ch, ushort value)
        {
            if (value > 4095) value = 4095;

            uint frame = (uint)(
                (0x3 << 20) |           // CMD = Write & Update
                ((int)ch << 16) |       // Address
                (value << 4)            // 12bit data
            );

            return new byte[]
            {
            (byte)((frame >> 16) & 0xFF),
            (byte)((frame >> 8) & 0xFF),
            (byte)(frame & 0xFF)
            };
        }

        // DC 出力
        public void WriteDc(Channel ch, ushort value)
        {
            var frame = BuildFrame(ch, value);

            spi.CsLow();
            spi.Write(frame);
            spi.CsHigh();
        }

        // 任意波形_高速化 (1ch), 更新時間任意設定 (intervalUs = us)
        public void WriteWaveform(Channel ch, ushort[] data, int intervalUs)
        {
            if (intervalUs < 1)
                throw new ArgumentOutOfRangeException(nameof(intervalUs));

            long ticksPerUs = TimeSpan.TicksPerMillisecond / 1000; // 1us = 10 ticks
            long waitTicks = intervalUs * ticksPerUs;

            // 事前に全フレーム生成（高速化）
            byte[][] frames = data.Select(v => BuildFrame(ch, v)).ToArray();

            foreach (var f in frames)
            {
                long start = DateTime.UtcNow.Ticks;

                spi.CsLow();
                spi.Write(f);
                spi.CsHigh();

                // 高精度 busy-wait
                while ((DateTime.UtcNow.Ticks - start) < waitTicks)
                {
                    // busy wait
                }
            }
        }
    }
}

