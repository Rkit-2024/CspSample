﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Device.SpiDriver;

namespace Device.Dac
{
    public class Ad5770r
    {
        private readonly ISpiDriver spi;

        public Ad5770r(ISpiDriver spi)
        {
            this.spi = spi;
            spi.SetMode(1);           // AD5770R は Mode1
            spi.SetSpeed(10_000_000); // 10MHz 程度
        }

        private void WriteReg(byte addr, ushort data)
        {
            byte[] frame =
            {
        addr,
        (byte)(data >> 8),
        (byte)(data & 0xFF)
    };

            spi.CsLow();
            spi.Write(frame);
            spi.CsHigh();
        }

        public void InitCh1(ushort rangeCode)
        {
            // CH1 enable (0x01, bit1)
            WriteReg(0x01, 0x0002);

            // CH1 range (0x03)
            WriteReg(0x03, rangeCode);
        }

        private byte[] BuildCh1Frame(ushort code)
        {
            const byte CH1_CODE_ADDR = 0x0B;

            return new byte[]
            {
        CH1_CODE_ADDR,
        (byte)(code >> 8),
        (byte)(code & 0xFF)
            };
        }

        public void WriteCh1(ushort code)
        {
            var frame = BuildCh1Frame(code);
            spi.CsLow();
            spi.Write(frame);
            spi.CsHigh();
        }

        public void WriteWaveformCh1(ushort[] data, int intervalUs, CancellationToken token)
        {
            if (intervalUs < 1)
                throw new ArgumentOutOfRangeException(nameof(intervalUs));

            long ticksPerUs = TimeSpan.TicksPerMillisecond / 1000;
            long waitTicks = intervalUs * ticksPerUs;

            var frames = data.Select(BuildCh1Frame).ToArray();

            while (!token.IsCancellationRequested)
            {
                foreach (var frame in frames)
                {
                    if (token.IsCancellationRequested) break;

                    long start = DateTime.UtcNow.Ticks;

                    spi.CsLow();
                    spi.Write(frame);
                    spi.CsHigh();

                    while ((DateTime.UtcNow.Ticks - start) < waitTicks)
                    {
                        if (token.IsCancellationRequested) break;
                    }
                }
            }
        }
    }
}
