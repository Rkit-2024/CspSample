﻿using System;
using System.Runtime.InteropServices;

namespace Device.SpiDriver
{
    /*****************************************************************************
        FTDI/FT232HC : SPI-USBコンバータIC用制御コマンド
    *****************************************************************************/
    public class FtdiSpi : ISpiDriver
    {
        private IntPtr handle = IntPtr.Zero;

        private ChannelConfig cfg;

        private uint gpioDir = 0b11110000;  // ADBUS4〜7 を出力に
        private uint gpioVal = 0b00000000;  // 初期値 Low

        private uint csPinMask = 1 << 3;    // ★ デフォルトは ADBUS3（従来と同じ）

        [DllImport("libMPSSE.dll")]
        private static extern uint SPI_OpenChannel(uint index, ref IntPtr handle);

        [DllImport("libMPSSE.dll")]
        private static extern uint SPI_CloseChannel(IntPtr handle);

        [DllImport("libMPSSE.dll")]
        private static extern uint SPI_InitChannel(IntPtr handle, ref ChannelConfig config);

        [DllImport("libMPSSE.dll")]
        private static extern uint SPI_ReadWrite(
            IntPtr handle,
            byte[] inBuffer,
            byte[] outBuffer,
            uint size,
            ref uint sizeTransferred,
            uint options);

        [DllImport("libMPSSE.dll")]
        private static extern uint SPI_Write(
            IntPtr handle,
            byte[] buffer,
            uint size,
            ref uint sizeTransferred,
            uint options);

        [DllImport("libMPSSE.dll")]
        private static extern uint SPI_Read(
            IntPtr handle,
            byte[] buffer,
            uint size,
            ref uint sizeTransferred,
            uint options);

        [DllImport("libMPSSE.dll")]
        private static extern uint FT_WriteGPIO(IntPtr handle, uint dir, uint value);

        [DllImport("libMPSSE.dll")]
        private static extern uint FT_ReadGPIO(IntPtr handle, out uint value);

        [StructLayout(LayoutKind.Sequential)]
        public struct ChannelConfig
        {
            public uint ClockRate;
            public byte LatencyTimer;
            public uint ConfigOptions;
            public uint Pin;
            public uint PinDir;
        }

        public void Open()
        {
            SPI_OpenChannel(0, ref handle);

            cfg = new ChannelConfig();
            cfg.ClockRate = 1000000; // 1MHz
            cfg.LatencyTimer = 2;
            cfg.ConfigOptions = 0x00000000; // SPI Mode 0

            SPI_InitChannel(handle, ref cfg);
        }

        public void Close()
        {
            SPI_CloseChannel(handle);
        }

        // SPI 速度変更
        public void SetSpeed(uint hz)
        {
            cfg.ClockRate = hz;
            SPI_InitChannel(handle, ref cfg);
        }

        // SPI モード変更
        public void SetMode(int mode)
        {
            cfg.ConfigOptions = (uint)mode;
            SPI_InitChannel(handle, ref cfg);
        }

        // --- CS ピンを任意設定 ---
        public void SetCsPin(int pin)
        {
            if (pin < 0 || pin > 7)
                throw new ArgumentOutOfRangeException(nameof(pin));

            csPinMask = (uint)(1 << pin);

            // CS ピンを出力に設定
            gpioDir |= csPinMask;
            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        //  CS 手動制御（Low）
        public void CsLow()
        {
            gpioVal &= ~csPinMask;  // 指定ピンだけ Low
            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        // CS 手動制御（High）
        public void CsHigh()
        {
            gpioVal |= csPinMask;   // 指定ピンだけ High
            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        // フルデュプレックス転送
        public byte[] Transfer(byte[] tx)
        {
            byte[] rx = new byte[tx.Length];
            uint transferred = 0;

            SPI_ReadWrite(handle, tx, rx, (uint)tx.Length, ref transferred, 0);

            return rx;
        }

        // 書き込み専用
        public void Write(byte[] data)
        {
            uint transferred = 0;
            SPI_Write(handle, data, (uint)data.Length, ref transferred, 0);
        }

        // 任意バイト読み出し
        public byte[] ReadBytes(int count)
        {
            byte[] tx = new byte[count];
            return Transfer(tx);
        }

        // 16bit 読み出し
        public ushort Read16()
        {
            var rx = ReadBytes(2);
            return (ushort)(rx[0] << 8 | rx[1]);
        }

        // 24bit 読み出し
        public uint Read24()
        {
            var rx = ReadBytes(3);
            return (uint)(rx[0] << 16 | rx[1] << 8 | rx[2]);
        }

        // 32bit 読み出し
        public uint Read32()
        {
            var rx = ReadBytes(4);
            return (uint)(rx[0] << 24 | rx[1] << 16 | rx[2] << 8 | rx[3]);
        }

        // GPIO/任意chの方向設定
        public void GpioSetDirection(int pin, bool isOutput)
        {
            if (pin < 0 || pin > 7)
                throw new ArgumentOutOfRangeException(nameof(pin));

            if (isOutput)
                gpioDir |= (uint)(1 << pin);
            else
                gpioDir &= ~(uint)(1 << pin);

            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        // GPIO/任意chの書き込み
        public void GpioWrite(int pin, bool level)
        {
            if (pin < 0 || pin > 7)
                throw new ArgumentOutOfRangeException(nameof(pin));

            if (level)
                gpioVal |= (uint)(1 << pin);
            else
                gpioVal &= ~(uint)(1 << pin);

            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        // GPIO/任意chの読み取り
        public bool GpioRead(int pin)
        {
            if (pin < 0 || pin > 7)
                throw new ArgumentOutOfRangeException(nameof(pin));

            FT_ReadGPIO(handle, out uint val);
            return ((val >> pin) & 1) == 1;
        }

        // GPIO/一括方向設定
        public void GpioSetDirectionMask(uint dirMask)
        {
            gpioDir = dirMask;
            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        // GPIO/一括書き込み
        public void GpioWriteMask(uint mask)
        {
            gpioVal = mask;
            FT_WriteGPIO(handle, gpioDir, gpioVal);
        }

        // GPIO/一括読み取り
        public uint GpioReadMask()
        {
            FT_ReadGPIO(handle, out uint val);
            return val;
        }
    }
}