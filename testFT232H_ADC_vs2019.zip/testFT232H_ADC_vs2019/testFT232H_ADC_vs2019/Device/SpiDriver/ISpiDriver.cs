﻿namespace Device.SpiDriver
{
    /*****************************************************************************
        SPI-USBコンバータ用共通インターフェース
    *****************************************************************************/
    public interface ISpiDriver
    {
        // SPI Configuration
        void Open();
        void Close();
        void SetSpeed(uint hz);
        void SetMode(int mode);

        // CS Manual Control
        void SetCsPin(int pin);
        void CsLow();
        void CsHigh();

        // SPI DataTransfer
        byte[] Transfer(byte[] tx);

        // SPI Write
        void Write(byte[] data);

        // SPI Read
        byte[] ReadBytes(int count);    // 任意バイト読み出し
        ushort Read16();
        uint Read24();
        uint Read32();

        // GPIO制御 (ch4 - 7)
        void GpioSetDirection(int pin, bool isOutput);
        void GpioWrite(int pin, bool level);
        bool GpioRead(int pin);

        // GPIO一括制御 (ch4 - 7)
        void GpioSetDirectionMask(uint dirMask);
        void GpioWriteMask(uint mask);
        uint GpioReadMask();
    }
}
