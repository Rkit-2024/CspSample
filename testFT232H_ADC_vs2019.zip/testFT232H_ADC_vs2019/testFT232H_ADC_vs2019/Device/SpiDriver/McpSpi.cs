﻿using System;
using System.Linq;
using System.Threading;
using HidSharp;

namespace Device.SpiDriver
{
    /*****************************************************************************
        MICROCHIP/MCP2210 : SPI-USBコンバータIC用制御コマンド
    *****************************************************************************/
    public class McpSpi : ISpiDriver
    {
        private HidDevice device;
        private HidStream stream;

        private const int VendorId = 0x04D8;  // Microchip
        private const int ProductId = 0x00DE; // MCP2210

        // SPI設定値
        private uint bitrate = 1000000; // default 1MHz
        private byte idleCs = 0x00;
        private byte activeCs = 0x00;
        private byte spiMode = 0x00;
        private byte csToDataDelay = 0x00;
        private byte lastDataToCsDelay = 0x00;
        private byte interDataDelay = 0x00;

        // GPIO設定値
        private uint gpioDir = 0x00000000; // 0=input, 1=output
        private uint gpioVal = 0x00000000; // 0=Low, 1=High


        public void Open()
        {
            var list = DeviceList.Local;
            device = list.GetHidDevices(0x04D8, 0x00DE).FirstOrDefault();

            if (device == null)
                throw new Exception("MCP2210 が見つかりません");

            stream = device.Open();
            stream.ReadTimeout = Timeout.Infinite;
            stream.WriteTimeout = Timeout.Infinite;

            LoadCurrentGpioConfig();
            LoadCurrentGpioConfig();
        }

        public void Close()
        {
            if (stream != null)
                stream.Close();
        }

        // HID レポート送信
        private void WriteReport(byte[] report)
        {
            stream.Write(report);
        }

        private byte[] ReadReport()
        {
            byte[] buf = new byte[64];
            stream.Read(buf, 0, buf.Length);
            return buf;
        }


        // SPIconfig Read 0x41
        private void LoadCurrentSpiConfig()
        {
            byte[] report = new byte[64];
            report[1] = 0x41; // Get SPI Config

            WriteReport(report);
            var res = ReadReport();

            bitrate = (uint)(res[2] | (res[3] << 8));
            idleCs = res[4];
            activeCs = res[5];
            spiMode = res[6];
            csToDataDelay = res[7];
            lastDataToCsDelay = res[8];
            interDataDelay = res[9];
        }

        // SPI config Write 0x40
        private void ApplySpiConfig()
        {
            byte[] report = new byte[64];
            report[1] = 0x40; // Set SPI Config

            report[2] = (byte)(bitrate & 0xFF);
            report[3] = (byte)((bitrate >> 8) & 0xFF);

            report[4] = idleCs;
            report[5] = activeCs;
            report[6] = spiMode;
            report[7] = csToDataDelay;
            report[8] = lastDataToCsDelay;
            report[9] = interDataDelay;

            WriteReport(report);
            ReadReport();
        }

        // SPI通信速度設定
        public void SetSpeed(uint hz)
        {
            if (hz < 150000 || hz > 12000000)
                throw new ArgumentOutOfRangeException(nameof(hz));

            bitrate = hz;
            ApplySpiConfig();
        }

        // SPI通信モード設定
        public void SetMode(int mode)
        {
            if (mode < 0 || mode > 3)
                throw new ArgumentOutOfRangeException(nameof(mode));

            spiMode = (byte)mode;
            ApplySpiConfig();
        }

        // SPI CS Manual Control
        public void SetCsPin(int pin)
        { }
        public void CsLow() => GpioWrite(0, false);
        public void CsHigh() => GpioWrite(0, true);

        // SPI転送 0x42
        public byte[] Transfer(byte[] tx)
        {
            byte[] report = new byte[64];
            report[1] = 0x42; // SPI Transfer
            report[2] = (byte)tx.Length;
            report[3] = 0x00;

            Array.Copy(tx, 0, report, 4, tx.Length);

            WriteReport(report);
            var res = ReadReport();

            byte[] rx = new byte[tx.Length];
            Array.Copy(res, 4, rx, 0, tx.Length);

            return rx;
        }

        // SPI 書き込み

        public void Write(byte[] data)
        {
            Transfer(data);
        }

        // 任意バイト読み出し
        public byte[] ReadBytes(int count)
        {
            byte[] tx = new byte[count];
            return Transfer(tx);
        }

        // 16bit 読み出し
        public ushort Read16()
        {
            var rx = ReadBytes(2);
            return (ushort)((rx[0] << 8) | rx[1]);
        }

        // 24bit 読み出し
        public uint Read24()
        {
            var rx = ReadBytes(3);
            return (uint)((rx[0] << 16) | (rx[1] << 8) | rx[2]);
        }

        // 32bit 読み出し
        public uint Read32()
        {
            var rx = ReadBytes(4);
            return (uint)((rx[0] << 24) | (rx[1] << 16) | (rx[2] << 8) | rx[3]);
        }

        // GPIO設定読み出し
        private void LoadCurrentGpioConfig()
        {
            byte[] report = new byte[64];
            report[1] = 0x21; // Get GPIO

            WriteReport(report);
            var res = ReadReport();

            gpioDir = res[4];
            gpioVal = res[5];
        }

        // GPIO設定書き込み
        private void ApplyGpioConfig()
        {
            byte[] report = new byte[64];
            report[1] = 0x20; // Set GPIO

            report[4] = (byte)gpioDir;
            report[5] = (byte)gpioVal;

            WriteReport(report);
            ReadReport();
        }


        // GPIO/任意ch方向設定
        public void GpioSetDirection(int pin, bool isOutput)
        {
            if (pin < 0 || pin > 8)
                throw new ArgumentOutOfRangeException(nameof(pin));

            if (isOutput)
                gpioDir |= (uint)(1 << pin);
            else
                gpioDir &= ~(uint)(1 << pin);

            ApplyGpioConfig();
        }

        // GPIO/任意chの書き込み
        public void GpioWrite(int pin, bool level)
        {
            if (pin < 0 || pin > 8)
                throw new ArgumentOutOfRangeException(nameof(pin));

            if (level)
                gpioVal |= (uint)(1 << pin);
            else
                gpioVal &= ~(uint)(1 << pin);

            ApplyGpioConfig();
        }

        // GPIO/任意chの読み取り
        public bool GpioRead(int pin)
        {
            if (pin < 0 || pin > 8)
                throw new ArgumentOutOfRangeException(nameof(pin));

            LoadCurrentGpioConfig();
            return ((gpioVal >> pin) & 1) == 1;
        }

        // GPIO/一括方向設定
        public void GpioSetDirectionMask(uint dirMask)
        {
            gpioDir = dirMask & 0x1FF; // 9bit
            ApplyGpioConfig();
        }

        // GPIO/一括書き込み
        public void GpioWriteMask(uint mask)
        {
            gpioVal = mask & 0x1FF;
            ApplyGpioConfig();
        }

        // GPIO/一括読み取り
        public uint GpioReadMask()
        {
            LoadCurrentGpioConfig();
            return gpioVal;
        }
    }
}

