﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NationalInstruments.NI845x;

namespace Device.SpiDriver
{
    /*****************************************************************************
        NI/USB-8452 : SPI-USBコンバータ用制御コマンド

        NI-845x Driverをインストール
        NationalInstruments.NI845x.dllを参照
    *****************************************************************************/
    public class Ni8452Spi : ISpiDriver
    {
        private NI845xDevice device;
        private NI845xSpi spi;
        private NISpiConfiguration config;

        private uint speed = 1000000;
        private int mode = 0;

        public void Open()
        {
            device = new NI845xDevice();
            spi = new NI845xSpi(device);

            config = new NISpiConfiguration
            {
                ClockRate = speed,
                ClockPolarity = (mode == 2 || mode == 3),
                ClockPhase = (mode == 1 || mode == 3),
                ChipSelectActiveState = false, // Active Low
                ChipSelect = 0 // CS0
            };
        }

        public void Close()
        {
            if (spi != null)
            {
                spi.Dispose();
                spi = null;
            }

            if (device != null)
            {
                device.Dispose();
                device = null;
            }
        }

        public void SetSpeed(uint hz)
        {
            speed = hz;
            config.ClockRate = hz;
        }

        public void SetMode(int m)
        {
            mode = m;
            config.ClockPolarity = (m == 2 || m == 3);
            config.ClockPhase = (m == 1 || m == 3);
        }

        // CS Manula Control
        public void SetCsPin(int pin)
        { }

        public void CsLow()
        {
            // USB‑8452 は CS を GPIO として制御可能
            device.SetIoLine(0, false);
        }

        public void CsHigh()
        {
            device.SetIoLine(0, true);
        }

        public byte[] Transfer(byte[] tx)
        {
            byte[] rx = new byte[tx.Length];
            spi.WriteRead(config, tx, rx);
            return rx;
        }

        public void Write(byte[] data)
        {
            spi.Write(config, data);
        }

        public byte[] ReadBytes(int count)
        {
            byte[] tx = new byte[count];
            return Transfer(tx);
        }

        public ushort Read16()
        {
            var rx = ReadBytes(2);
            return (ushort)((rx[0] << 8) | rx[1]);
        }

        public uint Read24()
        {
            var rx = ReadBytes(3);
            return (uint)((rx[0] << 16) | (rx[1] << 8) | rx[2]);
        }

        public uint Read32()
        {
            var rx = ReadBytes(4);
            return (uint)((rx[0] << 24) | (rx[1] << 16) | (rx[2] << 8) | rx[3]);
        }

        // GPIO 制御
        public void GpioSetDirection(int pin, bool isOutput)
        {
            device.SetIoDirection(pin, isOutput);
        }

        public void GpioWrite(int pin, bool level)
        {
            device.SetIoLine(pin, level);
        }

        public bool GpioRead(int pin)
        {
            return device.GetIoLine(pin);
        }

        public void GpioSetDirectionMask(uint mask)
        {
            for (int i = 0; i < 8; i++)
                device.SetIoDirection(i, ((mask >> i) & 1) == 1);
        }

        public void GpioWriteMask(uint mask)
        {
            for (int i = 0; i < 8; i++)
                device.SetIoLine(i, ((mask >> i) & 1) == 1);
        }

        public uint GpioReadMask()
        {
            uint val = 0;
            for (int i = 0; i < 8; i++)
                if (device.GetIoLine(i))
                    val |= (uint)(1 << i);
            return val;
        }
    }
}
