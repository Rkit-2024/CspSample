﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace testFT232H_ADC.Logic
{
    /*****************************************************************************
        グラフ更新
    *****************************************************************************/
    internal class GraphRenderer
    {
        public void Draw(Canvas canvas, List<int> samples)
        {
            canvas.Children.Clear();

            if (samples.Count < 2)
                return;

            double w = canvas.ActualWidth;
            double h = canvas.ActualHeight;

            if (w <= 0 || h <= 0)
                return;

            double dx = w / (samples.Count - 1);
            double scaleY = h / 4096.0;

            Polyline line = new Polyline
            {
                Stroke = Brushes.Lime,
                StrokeThickness = 2
            };

            for (int i = 0; i < samples.Count; i++)
            {
                double x = i * dx;
                double y = h - samples[i] * scaleY;
                line.Points.Add(new Point(x, y));
            }

            canvas.Children.Add(line);
        }
    }
}
