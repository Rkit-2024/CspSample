﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;

using Device.SpiDriver;
using Device.Dac;

namespace testFT232H_ADC
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class WindowAD5778R : Window
    {
        private ISpiDriver spi;
        private Ad5778r dac;
        private ushort[] wave = Array.Empty<ushort>();
        private CancellationTokenSource cts;

        public WindowAD5778R()
        {
            InitializeComponent();

            if (DesignerProperties.GetIsInDesignMode(new DependencyObject()))
                return;

            try
            {
                spi = new FtdiSpi();

                spi.Open();
                spi.SetCsPin(4);

                dac = new Ad5778r(spi);
                StatusText.Text = "SPI/AD5778R initialized.";
            }
            catch (Exception ex)
            {
                StatusText.Text = $"Init error: {ex.Message}";
            }
        }

        private void LoadCsvButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*"
            };

            if (dlg.ShowDialog() != true)
                return;

            try
            {
                var lines = File.ReadAllLines(dlg.FileName);

                var values = lines
                    .Select(l => l.Trim())
                    .Where(l => !string.IsNullOrWhiteSpace(l))
                    .Select(l =>
                    {
                        var parts = l.Split(',', ';', '\t');
                        return double.Parse(parts[0]); // 1列目
                    })
                    .ToArray();

                // 0〜65535 を想定（必要なら 0〜4095 などに変更）
                wave = values
                    .Select(v =>
                    {
                        if (v < 0) v = 0;
                        if (v > 65535) v = 65535;
                        return (ushort)v;
                    })
                    .ToArray();

                PointsInfoText.Text = wave.Length.ToString();
                StatusText.Text = $"CSV loaded: {wave.Length} pts";
            }
            catch (Exception ex)
            {
                StatusText.Text = $"CSV load error: {ex.Message}";
            }
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (dac == null || wave.Length == 0)
            {
                StatusText.Text = "No DAC or wave.";
                return;
            }

            if (cts != null)
            {
                StatusText.Text = "Already running.";
                return;
            }

            try
            {
                int intervalUs = int.Parse(IntervalBox.Text);
                if (intervalUs < 10 || intervalUs > 1_000_000)
                {
                    StatusText.Text = "Interval must be 10–1,000,000 us.";
                    return;
                }

                cts = new CancellationTokenSource();
                var token = cts.Token;

                StatusText.Text = "Running...";

                Task.Run(() =>
                {
                    try
                    {
                        dac.WriteWaveformCh1(wave, intervalUs, token);
                    }
                    catch (OperationCanceledException) { }
                    catch (Exception ex)
                    {
                        Dispatcher.Invoke(() => StatusText.Text = $"Run error: {ex.Message}");
                    }
                    finally
                    {
                        Dispatcher.Invoke(() =>
                        {
                            StatusText.Text = "Stopped.";
                            cts = null;
                        });
                    }
                }, token);
            }
            catch (Exception ex)
            {
                StatusText.Text = $"Start error: {ex.Message}";
            }
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            cts?.Cancel();
        }

        protected override void OnClosed(EventArgs e)
        {
            cts?.Cancel();
            spi?.Close();
            base.OnClosed(e);
        }

    }
}
